<template>
  <div>
    <!-- <login /> -->
    <!-- <book-my-show /> -->
    <!-- <todo /> -->
    <!-- <ProductCategory /> -->
    <!-- <event-demo /> -->
    <!-- <watcher-demo /> -->
    <computed-demo />
  </div>
</template>

<script>
//import Login from "./login.vue";
//import BookMyShow from "./BookMyShow.vue";
//import Todo from "./Todo.vue";
//import ProductCategory from "./CategoryAndProduct.vue";
//import EventDemo from "./EventDemo.vue";
// import WatcherDemo from "./WacherDemo.vue";
import ComputedDemo from "./ComputedDemo.vue";

export default {
  name: "App",
  components: {
    //Login
    //BookMyShow
    //Todo
    //ProductCategory
    // EventDemo
    // WatcherDemo
    ComputedDemo
  }
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
