<template>
  <div>
    <p>ID: {{ id }}</p>
    <p>Name: {{name}}</p>
  </div>
</template>

<script>
export default {
  name: "Product",
  data() {
    return {
      id: 1,
      name: "apple"
    };
  }
};
</script>

<style scoped>
</style>